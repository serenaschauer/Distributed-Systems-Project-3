import java.util.*;

import javax.jdo.*;

@javax.jdo.annotations.PersistenceCapable

public class Director extends Person
{

	public static Director find(String name, PersistenceManager pm)

	/* Returns a director with the given "name";
           if no such director exists, null is returned. 
           The function is applied to the database held by the persistence manager "pm". */

	{			
		Query q = pm.newQuery(Director.class);
		q.declareParameters("String name");
		q.setFilter("this.name == name");
    	
		Collection<Director> dd = (Collection<Director>) q.execute(name);
    	Director d = Utility.extract(dd);
    	q.close(dd);
    	return d;
	}

	public Collection<Movie> movies(Query q)

	/* Returns the collection of all movies directed by this director. 
	   Represents the inverse of Movie.director.
	   Sort the result by (Movie.title, Movie.releaseYear). */

	{
		q.setClass(Movie.class);
		q.declareParameters("Director d");
		q.setFilter("this.director == d");
		q.setOrdering("this.title ascending, this.releaseYear ascending");
		return(Collection<Movie>) q.execute(this);
	}

	public Collection<Studio> studiosWithThisDirector(Query q)

	/* Returns the collection of all studios that have made at least two movies
	   directed by this director.
	   Sort the result by Studio.name. */

	{
		q.setClass(Studio.class);
		q.declareParameters("Director d");
		q.declareVariables("Movie m1; Movie m2");
		q.setFilter("this.movies.contains(m1) &&" +
					"this.movies.contains(m2) &&" +
					"m1 != m2 && " +
					"m1.director == this && " +
					"m2.director == this"
					);
		q.setOrdering("this.name ascending");
		return(Collection<Studio>) q.execute(this);
	}
}


